#include <cmath>
#include <cstdlib>
#include <iostream>
using namespace std;

// Global constants
const int ROWS = 26;
const int COLS = 26;

//---------------------------------------------------
// Read read index of the form A4 and calculate
// the corresponding row=3 col=0 values.
//---------------------------------------------------
void read_index(int &row, int &col, char letter, int number, bool &QUIT) // modified to also take char letter and int number
{
   if (letter >= 'A' && letter <= 'Z')
      col = letter - 'A';
   else
   {
        cout << "Error: invalid column, quitting program\n";
        QUIT = true; // will end program if invalid cells are inputted, just in case it doesn't end it otherwise
   }
   if (number >= 1 && number <= 26)
      row = number - 1;
   else
   {
        cout << "Error: invalid row, quitting program\n";
        QUIT = true;
   }
      
}

//---------------------------------------------------
// Print range of values in spreadsheet array
//---------------------------------------------------
void print(float data[ROWS][COLS], char charRow1, int intCol1, char charRow2, int intCol2, bool &QUIT)
{
   int r1;
   int r2;
   int c1;
   int c2;
   
   read_index(r1, c1, charRow1, intCol1, QUIT);
   read_index(r2, c2, charRow2, intCol2, QUIT);
   
   for (int row = r1; row <= r2; row++)
   {
      for (int col = c1; col <= c2; col++)
         cout << data[row][col] << "\t";
      cout << endl;
   }
}

// ADD FUNCTIONS TO DO ARRAY OPERATIONS HERE

void store(float (&data)[ROWS][COLS], float value, char charRow, int intCol, bool &QUIT)
{
    int ROWS = 0;
    int COLS = 0;
    read_index(ROWS, COLS, charRow, intCol, QUIT);
    
    data[ROWS][COLS] = value;
}
// place random numbers within certain range
void random(float (&data)[ROWS][COLS], int min, int max, char charRow1, char charRow2, int intCol1, int intCol2, bool &QUIT)
{
    // row and column for 1st cell location
    int ROW1 = 0; 
    int COL1 = 0;
    // row and column for 2nd cell location
    int ROW2 = 0; 
    int COL2 = 0;
    
    // get indexes
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    
    if (max < min) cout << "Max is less than Min, values are swapped" << endl;
    
    // for loops to go through all cells and put random number within range indicated
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
        {
            if (max >= min)
            {
                data[row][col] = rand() % max + min;
            }
            else if(max < min)
            {
                data[row][col] = rand() % min + max;
            }
        }
    }
    
}
// get minimum
void minimum(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float min;
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    min = data[ROW1][COL1]; // sets min as first cell value and then will compare with rest of the cells in for loop below
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
            if (data[row][col] <= min)
                min = data[row][col];
    }
    data[ROW3][COL3] = min;
}

void maximum(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float max;
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    max = data[ROW1][COL1]; // sets max as first cell value and then will compare with rest of the cells in for loop below
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
        {
            if (data[row][col] >= max)
                max = data[row][col];
        }
    }
    data[ROW3][COL3] = max;
}

void sum(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float total = 0;
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
        {
            total = total + data[row][col];
        }
    }
    data[ROW3][COL3] = total;
}

void average(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float total = 0;
    float count = 0;
    float ave = 0;
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
        {
            total = total + data[row][col];
            count = count + 1;
        }
    }
    ave = total / count;
    data[ROW3][COL3] = ave;
}
// I used SAMPLE Variance
void variance(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float ave = 0;
    float total = 0;
    float count = 0;
    float var;
    
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    // Calls Average and temporarily places it in cell3, will be overwritten with the variance when function finishes
    average(data, charRow1, charRow2, charRow3, intCol1, intCol2, intCol3, QUIT);
    ave = data[ROW3][COL3];
    
    
    for (int row = ROW1; row <= ROW2; row++)
    {
        for (int col = COL1; col <= COL2; col++)
        {
            total = total + ((data[row][col] - ave) * (data[row][col] - ave)); // sum of (x - xbar)^2
            count = count + 1;
        }
    }
    count = count - 1;
    var = total / count;
    data[ROW3][COL3] = var;
}

void stdeviation(float (&data)[ROWS][COLS], char charRow1, char charRow2, char charRow3, int intCol1, int intCol2, int intCol3, bool &QUIT) 
{
    int ROW1 = 0; 
    int COL1 = 0;
    int ROW2 = 0; 
    int COL2 = 0;
    int ROW3 = 0; 
    int COL3 = 0;
    float var = 0;
    float stdevi = 0;
    
    read_index(ROW1, COL1, charRow1, intCol1, QUIT);
    read_index(ROW2, COL2, charRow2, intCol2, QUIT);
    read_index(ROW3, COL3, charRow3, intCol3, QUIT);
    
    variance(data, charRow1, charRow2, charRow3, intCol1, intCol2, intCol3, QUIT);
    var = data[ROW3][COL3];
    stdevi = sqrt(var);
    
    data[ROW3][COL3] = stdevi;
}


//---------------------------------------------------
// Main program, only 2 functions implemented so far, STORE, RANDOM, No error checking yet except for inputting invalid COMMAND
//---------------------------------------------------
int main()
{
   // Initialize spreadsheet
   float data[ROWS][COLS];
   for (int row = 0; row < ROWS; row++)
      for (int col = 0; col < COLS; col++)
         data[row][col] = 0;

    // initialize all possible inputs
    float value1;
    char row1;
    int col1;
    char row2;
    int col2;
    char row3;
    int col3;
    int min; // get range for values for RANDOM command
    int max;


   // Main While loop to read inputs for commands and stuff
   bool QUIT = false;
   while (QUIT != true)
   {
       string command;
       
       cout << "Enter command and then your values and/or Cell locations (e.g. A1... B6)\n Type 'HELP' to see list of commands: ";
       cin >> command;
       cout << endl;
       
       
       // if statement checks command string first to select the right variables to take cin
       if (command == "STORE")
       {
           // Message outputs to confirm user what command was read
           cout << endl << "STORE COMMAND CALLED" << endl;
           
           
           
           // Rest of input assigned and then function is called
           cin >> value1 >> row1 >> col1;
           store(data, value1, row1, col1, QUIT);
           
       }
       else if (command == "HELP")
       {
           cout << "CellStart/End is the range you want the command to read" << endl
                << "Showing Command List: " << endl
                << "PRINT [CellStart] [CellEnd]" << endl
                << "STORE [Value] [Cell]" << endl
                << "RANDOM [MinValue] [MaxValue] [CellStart] [CellEnd]" << endl
                << "MIN [CellStart] [CellEnd] [CellOutput]" << endl
                << "MAX [CellStart] [CellEnd] [CellOutput]" << endl
                << "SUM [CellStart] [CellEnd] [CellOutput]" << endl
                << "AVE [CellStart] [CellEnd] [CellOutput]" << endl
                << "VAR [CellStart] [CellEnd] [CellOutput]" << endl
                << "STDEV [CellStart] [CellEnd] [CellOutput]" << endl
                << "QUIT";
       }
       else if (command == "PRINT")
       {
           cout << endl << "PRINT COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2;
           print(data, row1, col1, row2, col2, QUIT);
           
       }
       
       else if (command == "RANDOM")
       {
            cout << "RANDOM COMMAND CALLED" << endl;
            
            
            
            cin >> min >> max >> row1 >> col1 >> row2 >> col2;
            random(data, min, max, row1, row2, col1, col2, QUIT);
            
       }
       
       else if (command == "MIN")
       {
           cout << endl << "MINIMUM COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           minimum(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       
       else if (command == "MAX")
       {
           cout << endl << "MAXIMUM COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           maximum(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       
       else if (command == "SUM")
       {
           cout << endl << "SUM COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           sum(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       
       else if (command == "AVE")
       {
           cout << endl << "AVERAGE COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           average(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       // NOTE: SAMPLE VARIANCE
       else if (command == "VAR")
       {
           cout << endl << "VARIANCE (SAMPLE) COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           variance(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       // Squareroot of SAMPLE VARIANCE
       else if (command == "STDEV")
       {
           cout << endl << "STANDARD DEVIATION COMMAND CALLED" << endl;
           
           
           
           cin >> row1 >> col1 >> row2 >> col2 >> row3 >> col3;
           stdeviation(data, row1, row2, row3, col1, col2, col3, QUIT);
       }
       
       else if (command == "QUIT")
       {
           cout << endl << "Quitting..." << endl;
           QUIT = true;
       }
       
       else // if it's not any of the commands above, ends the while loop/stops the program
       {
           cout << endl << "Invalid Command inputted, Quiting..." << endl;
           QUIT = true;
       }
   }
   

   return 0;
}


