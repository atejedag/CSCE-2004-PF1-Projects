/*First, your program must calculate the cost of the student’s wand based on the user’s choice of materials and size. 
Second, your program must simulate how the sorting hat will assign a student into one of the four Hogwarts Houses 
(Gryffindor, Hufflepuff, Ravenclaw, or Slytherin).*/

#include <iostream>
using namespace std;

int main()
{
    //State all variables
    int totalPrice; 
    int priceWood; 
    int priceCore; 
    int wandLength; 
    string woodType; //Acacia (a), Dogwood (d), Willow (w)
    string coreType; //Dragon Heartstring (d), Phoenix Feather (p), Wampus Cat Hair (w)
    string answer1;
    string answer2;
    string answer3;
    string studHouse;
    
    
    //Get inputs for wood, core, and length
    
    cout << "Choose a wood, type the corresponding letter to select it : " << endl
         << "(a) Acacia, 10 dollars/inch" << endl
         << "(d) Dogwood, 25 dollars/inch" << endl
         << "(w) Willow, 50 dollars/inch" << endl;
    
    cin >> woodType;
    cout << endl;
    
    cout << "Choose a core, type the corresponding letter to select it : " << endl
         << "(d) Dragon Heartstring, 75 dollars/inch" << endl
         << "(p) Phoenix Feather, 100 dollars/inch" << endl
         << "(w) Wampus Cat Hair, 50 dollars/inch" << endl;
    
    cin >> coreType;
    cout << endl;
    
    cout << "Choose the length for your wand between 8 and 15 inches: " << endl;
    cin >> wandLength;
    cout << endl;
    //End program if wandLength is less than or greater than 8 or 15
    if (wandLength < 8 || wandLength > 15) 
    {
        cout << "You didn't follow directions, now you're banished to the shadow realm jimbo";
        return 0;
    }
    
    
    //Determine which wood type was chosen and set the price for wood and core
    if (woodType == "A" || woodType == "a") 
    {
        woodType = "Acacia";
        priceWood = 10;
    }
    else if (woodType == "D" || woodType == "d") 
    {
        woodType = "Dogwood";
        priceWood = 25;
    }
    else if (woodType == "W" || woodType == "w") 
    {
        woodType = "Willow";
        priceWood = 40;
    }
    else //Stops program if input is invalid
    {
        cout << "You didn't follow directions, now you're banished to the shadow realm";
        return 0;
    }
    
    
    if (coreType == "D" || coreType == "d") 
    {
        coreType = "Dragon Heartstring";
        priceCore = 75;
    }
    else if (coreType == "P" || coreType == "p") 
    {
        coreType = "Phoenix Feather";
        priceCore = 100;
    }
    else if (coreType == "W" || coreType == "w") 
    {
        coreType = "Wampus Cat Hair";
        priceCore = 50;
    }
    else 
    {
        cout << "You didn't follow directions, now you're banished to the shadow realm, Jimbo";
    }
    
    //Output all choices and their prices
    cout << "Wood: " << woodType << endl
         << "\tPrice/inch = " << priceWood << endl
         << "Core: " << coreType << endl
         << "\tPrice/inch = " << priceCore << endl << endl
         << "Length: " << wandLength << " inches"
         << endl;
    
    //Calculate and Output the final price of the wand
    totalPrice = (priceWood + priceCore) * wandLength;
    cout << "Total Price for wand: $" << totalPrice << " plus tax" << endl << endl << endl;
    
    
    //Questionaire for deciding house
    cout << "Now a test to decide what house you will be in" << endl;
    cout << "Question 1:" << endl 
         << "If you could make a potion that would guarantee you one thing, what would it be?" << endl
         << "A. Love" << endl
         << "B. Wisdom" << endl
         << "Type A or B: ";
    cin >> answer1;
    
    
    cout << endl << "Question 2: " << endl
         << "When I am dead, I want people to remember me as: " << endl
         << "A. The Great" << endl
         << "B. THe Wise" << endl
         << "Type A or B: ";
    cin >> answer2;
    
    
    cout << endl << "Question 3: " << endl
         << "What would you least liked to be called?" << endl
         << "A. Cowardly" << endl
         << "B. Selfish" << endl
         << "Type A or B: ";
    cin >> answer3;
    
    
    //if statements to decide Houses
    if (answer1 == "A" || answer1 == "a")
    {
        if (answer3 == "A" || answer3 == "a") 
        {
            studHouse = "Gryffindor";
        }
        else if (answer3 == "B" || answer3 == "b") 
        {
            studHouse = "Hufflepuff";
        }
        else
        {
            cout << "You didn't follow directions, now you're banished to the shadow realm";
            return 0;
        }
    }
    else if (answer1 == "B" || answer1 == "b") 
    {
        if (answer2 == "A" || answer2 == "a") 
        {
            studHouse = "Slytherin";
        }
        else if (answer2 == "B" || answer2 == "b") 
        {
            studHouse = "Ravenclaw";
        }
        else
        {
            cout << "You didn't follow directions, now you're banished to the shadow realm";
            return 0; 
        }
    }
    else 
    {
        cout << endl << "You didn't follow directions, now you're banished to the shadow realm, Jimbo";
        return 0;
    }
    
    
    cout << endl << endl << "You're going to " << studHouse << endl;
    return 0;
}





