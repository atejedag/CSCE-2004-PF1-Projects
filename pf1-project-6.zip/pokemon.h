#include <iostream>
using namespace std;

class pokemon
{
public:
    pokemon(); // constructor
    pokemon(const pokemon & copy);
    ~pokemon(); // destructor
    
    void setPokemon(string name1, char gender1, string type1, float weight1);
    
    string getName(); // returns one of the pokemon's parameters
    char getGender();
    string getType();
    int getWeight();
    
    void print();

private:
    string name;
    char gender;
    string type;
    int weight;

};



pokemon::pokemon()
{
    name = "None";
    gender = 'n';
    type = "None";
    weight = 0;
}

pokemon::pokemon(const pokemon & pokemon)
{
    name = pokemon.name;
    gender = pokemon.gender;
    type = pokemon.type;
    weight = pokemon.weight;
}

pokemon::~pokemon()
{
    
}

// Set pokemon stats
void pokemon::setPokemon(string name1, char gender1, string type1, float weight1)
{
    name = name1;
    gender = gender1;
    type = type1;
    if (weight1 < 0)
    {
        cout << "Weight less than 0, setting to default..." << endl;
        weight = 5; // default value
    }
    else
    {
        weight = weight1;
    }
    
}

// return one of the stats
string pokemon::getName()
{
    return name;
}

char pokemon::getGender()
{
    return gender;
}

string pokemon::getType()
{
    return type;
}

int pokemon::getWeight()
{
    return weight;
}

// print out all of the stats
void pokemon::print()
{
    cout << "Name: " << name << endl
         << "Gender: " << gender << endl
         << "Type: " << type << endl
         << "Weight: " << weight << endl << endl;
}










