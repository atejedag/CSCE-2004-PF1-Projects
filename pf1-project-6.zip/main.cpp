#include <iostream>
#include "pokemon.h"
using namespace std;


int main()
{
    // setting the things
    pokemon poke1;
    pokemon poke2;
    pokemon poke3;
    pokemon poke4;
    
    // set all stats for pokemon
    poke1.setPokemon("Onion Turtle", 'F', "Grass/Poison", 5);
    poke2.setPokemon("Pikachu", 'M', "Electric", 6);
    poke3.setPokemon("Rayquaza", '?', "Dragon/Flying", 200);
    poke4.setPokemon("MissingNo.", '?', "Normal", 999);
    
    // print out all stats for each pokemon
    poke1.print();
    poke2.print();
    poke3.print();
    poke4.print();
    
    // test the get methods for getting individual stats
    cout << endl << endl
         << poke1.getName() << endl
         << poke2.getGender() << endl
         << poke3.getType() << endl
         << poke4.getWeight() << endl << endl;

    pokemon poke5(poke1); // test copy constructor
    poke5.print();
    

    return 0;
}
