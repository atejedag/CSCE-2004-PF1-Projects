// Project 4

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;


const int MAX_SPEED = 8;
const int MAX_PLAYER_HEALTH = 30;
const int MAX_DL_HEALTH = 50;

///////////// Basic Mechanisms /////////////////

// Stun: reduce the opponent's speed to 0.
bool Stun(const int SpeedDif) {
    double prob = (double) (SpeedDif + 1) / MAX_SPEED;
    double dice = (double) rand() / RAND_MAX;
    if (dice < prob)
        return true;
    else
        return false;
}

// Evade: avoid being hitting by the opponent's attack.
bool Evade(const int SpeedDif) {
    double prob = (double) (SpeedDif + 1) / (MAX_SPEED + 2);
    double dice = (double) rand() / RAND_MAX;
    if (dice < prob)
        return true;
    else
        return false;
}

////////// Unforgivable Curses ////////////////

// Avada Kedavra: Cause large health damage (health-10). Can be evaded if the player's speed is higher than the dark lord's speed.
void AvadaKedavra(int & PlayerHealth, int & PlayerSpeed,
    const int DLHealth,
        const int DLSpeed) {
    cout << "Dark Lord casts Avada Kedavra." << endl;
    int SpeedDif = PlayerSpeed - DLSpeed;
    if (Evade(SpeedDif) == false) {
        cout << "You are hit. Health-10." << endl;
        PlayerHealth -= 10;
    } else {
        cout << "You evaded it." << endl;
    }
}

// Imperio: Has chance of stun if the dark lord's speed is higher than the player's speed. 
void Imperio(int & PlayerHealth, int & PlayerSpeed,
    const int DLHealth,
        const int DLSpeed) {
    cout << "Dark Lord casts Imperio." << endl;
    int SpeedDif = DLSpeed - PlayerSpeed;
    if (Stun(SpeedDif) == true) {
        cout << "You are stunned." << endl;
        PlayerSpeed = 0;
    } else {
        cout << "It takes no effect on you." << endl;
    }
}

// Crucio: Cause medium damage and slow the player (health-5, speed-1). The player's speed cannot be reduced to 0 (minimum 1). 
// Can be evaded if the player's speed is higher than the dark lord's speed.
void Crucio(int & PlayerHealth, int & PlayerSpeed,
    const int DLHealth,
        const int DLSpeed) {
    cout << "Dark Lord casts Crucio." << endl;
    int SpeedDif = PlayerSpeed - DLSpeed;
    if (Evade(SpeedDif) == false) {
        cout << "You are hit. Health-5. Speed-1." << endl;
        PlayerHealth -= 5;
        if (PlayerSpeed>1) PlayerSpeed -= 1;
    } else {
        cout << "You evaded it." << endl;
    }
}

////////// Dark Lord Move ////////////////

void DLMove(int & PlayerHealth, int & PlayerSpeed,
    const int DLHealth,
        const int DLSpeed) {
    int choice = rand() % 3;
    switch (choice) {
    case 0:
        AvadaKedavra(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
        break;
    case 1:
        Imperio(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
        break;
    case 2:
        Crucio(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
        break;
    default:
        ;
    }
}

////////// Hogwarts Spells ////////////////

// Expelliarmus (Disarming Spell): Has chance of stun if the player's speed is higher than the opponent's speed.
void Expelliarmus(const int PlayerHealth,
    const int PlayerSpeed, int & DLHealth, int & DLSpeed) {
    
    cout << "Player uses Expelliarmus" << endl;
    int SpeedDif = PlayerSpeed - DLSpeed;
    
    if (Stun(SpeedDif) == true)
    {
        cout << "Dark Lord is stunned" << endl;
        DLSpeed = 0;
    }
    else
    {
        cout << "It has no effect on the Dark Lord" << endl;
    }
}

// basic attack spell, does 5 damage base, then randomly gives 0-5 bonus damage and can be evaded, 
// also has chance to reduce speed by 2 if Dark Lords speed is >= 5
void Attack(int const PlayerHealth, int const PlayerSpeed, int & DLHealth, int & DLSpeed)
{
    cout << "You cast generic damage dealing spell, Attackio" << endl;
    int SpeedDif = DLSpeed - PlayerSpeed;
    int SpeedChance;
    int TotalAttack;
    if (Evade(SpeedDif) == false)
    {
        TotalAttack = 5 + (rand() % 6); // calculate bonus damage
        
        cout << "You hit the Dark Lord, Health -" << TotalAttack << endl;
        DLHealth = DLHealth - TotalAttack;
        if (DLSpeed >= 5)
        {
            SpeedChance = rand() % 2;
            if (SpeedChance == 0)
            {
                cout << "Dark lord's speed was also reduced by 2!" << endl;
                DLSpeed = DLSpeed - 2;
            }
            
        }
    }
    else
    {
        cout << "Dark Lord Evaded the attack" << endl; 
    }
}

// Heals player and has a chance to heal double but cannot heal over max player health
void PlayerHeal(int & PlayerHealth, const int MAX_PLAYER_HEALTH)
{
    int ChanceHeal;
    ChanceHeal = rand() % 4;
    if (ChanceHeal == 0)
    {
        cout << "Player Casts heal, it's a great heal! +10 health" << endl;
        PlayerHealth = PlayerHealth + 10;
    }
    else
    {
        cout << "Player casts heal, it's a regular heal, +5 health" << endl;
        PlayerHealth = PlayerHealth + 5;
    }
    
    // If health goes over max, will set health to max
    if (PlayerHealth > MAX_PLAYER_HEALTH)
        {
            PlayerHealth = MAX_PLAYER_HEALTH;
        }
    }



////////// Player Move ////////////////
void PlayerMove(int & PlayerHealth,
    const int PlayerSpeed, int & DLHealth, int & DLSpeed) {
    
    int PlayerChoice = 0;
    bool loopBreak = false;
    
    // While loop to have playerchoice be within range
    while ((PlayerChoice < 1 || PlayerChoice > 3) && loopBreak == false)
    {
        cout << "Choose your spell:\n"; 
        cout << "(1) Basic attack with chance of being evaded, damage varies 5-10 and chance to reduce speed of oppenent by 2 if speed is greater than 5\n"; 
        cout << "(2) Expelliarmus, chance to stun if your speed is greater than Dark Lord's speed\n";
        cout << "(3) Heal, chance to heal small amount of health (+5) or great amount of health (+10)\n";
        cin >> PlayerChoice;
        
        if (PlayerChoice < 1 || PlayerChoice > 3)
        {
            cout << "Not within spell selection range, try again" << endl;
        }
        
        // if input isn't an integer, just kill player and stop loop so no infinite loop is caused
        if (int(PlayerChoice) == false)
        {
            cout << "Invalid data type inputted... Corrupted Spell chanted, -3000 health" << endl;
            PlayerHealth = PlayerHealth - 30;
            loopBreak = true;
        }
        
    }

    // switch statement to decide skill to use and call that function
    switch (PlayerChoice) {
    case 1:
        Attack(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
        break;
    case 2:
        Expelliarmus(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
        break;
    case 3:
        PlayerHeal(PlayerHealth, MAX_PLAYER_HEALTH);
        break;
    default:
        ;
    }
}

////////// Main Function ////////////////
int main() {
    srand(time(NULL));

    int PlayerHealth = MAX_PLAYER_HEALTH;
    int PlayerSpeed = MAX_SPEED;
    int DLHealth = MAX_DL_HEALTH;
    int DLSpeed = MAX_SPEED;
    int roundStarter;

    cout << "Battle begins!" << endl;
	
	int round = 1;
	
    while ((PlayerHealth > 0) && (DLHealth > 0)) {
		
		cout << "---------------Round " << round << "---------------" << endl;
		
		// Restore 1 speed at the begining of each round.
        if (PlayerSpeed<MAX_SPEED) PlayerSpeed += 1;
        if (DLSpeed<MAX_SPEED) DLSpeed += 1;

        cout << "Your health is " << PlayerHealth << ", speed is " << PlayerSpeed << ".\n";
        cout << "Dark Lord's health is " << DLHealth << ", speed is " << DLSpeed << ".\n";
		
		
		// If both Player and dark lord have same speed and then randomly choose order 50/50 chance 
		if (PlayerSpeed == DLSpeed)
		{
		    roundStarter = rand() % 2;
		    if (roundStarter == 0)
		    {
		        cout << "Player goes first!" << endl;
		        PlayerMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        if (DLSpeed > 0)
		        {
		            DLMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        }
		        else 
		        {
		            cout << "Dark Lord is stunned, turn skipped!" << endl;
		        }
		        
		        cout << "END OF ROUND" << endl << endl;
		    }
		    else // roundstarter == 1
		    {
		        cout << "Dark Lord goes first!" << endl;
		        DLMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        
		        if (PlayerSpeed > 0) // check if stunned
		        {
		            PlayerMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        }
		        else
		        {
		            cout << "Player is stunned, turn skipped!" << endl;
		        }
		        
		        cout << "END OF ROUND" << endl << endl;
		    }
		}
		    // if statements for if one speed is greater than the other
	    else if (PlayerSpeed > DLSpeed) 
	    {
	        cout << "Player goes first!" << endl;
	        PlayerMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
	        
	        if (DLSpeed > 0) // check if stunned
		        {
		            DLMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        }
		        else 
		        {
		            cout << "Dark Lord is stunned, turn skipped!" << endl;
		        }
	        
	        cout << "END OF ROUND" << endl << endl;
	    }
	    else if (DLSpeed > PlayerSpeed)
	    {
	        cout << "Dark lord goes first!" << endl;
	        DLMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
	        if (PlayerSpeed > 0) // check if stunned
		        {
		            PlayerMove(PlayerHealth, PlayerSpeed, DLHealth, DLSpeed);
		        }
		        else
		        {
		            cout << "Player is stunned, turn skipped!" << endl;
		        }
	        
	        cout << "END OF ROUND" << endl << endl;
	    }
		    
		round++;
    }

    if (PlayerHealth > 0)
        cout << "Dark Lord died! You win!" << endl;
    else
        cout << "You died! Dark lord wins." << endl;

    return 0;
}



