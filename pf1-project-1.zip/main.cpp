#include <iostream>
using namespace std;


int main()
{
   
//State Variables
    int box_h = 0;
    int box_w = 0;
    int box_l = 0;
    int truck_h = 0;
    int truck_w = 0;
    int truck_l = 0;
    int boxVol = 0;
    int totalboxVol = 0;
    int truckVol = 0;
    int maxbox_h = 0;
    int maxbox_w = 0;
    int maxbox_l = 0;
    int totalBoxes = 0;
    int finaltruckVol = 0;
    float percentUsed = 0;
    
//Get inputs for box and truck dimensions
    cout << "Box size: Height x Width x Length in inches (Each seperated by a space): " << endl;
    cin >> box_h >> box_w >> box_l;
    
    cout << "Interior size of truck: Height x Width x Length in feet (Each seperated by a space): " << endl;
    cin >> truck_h >> truck_w >> truck_l;
    
    
//Convert feet to inches for truck dimensions
    truck_h = truck_h * 12, truck_w = truck_w * 12, truck_l = truck_l * 12; 
    
    
//Volumes for Truck and Box
    boxVol = box_h * box_w * box_l, truckVol = truck_h * truck_w * truck_l;
    

//Outputs all dimensions to make sure its all correct
    cout << "Box and Truck Dimensions in inches" << endl;
    cout << "Box Height: " << box_h << " in" << endl 
         << "Box Width: " << box_w << " in" << endl 
         << "Box Length: " << box_l << " in" << endl << endl;
    cout << "Truck Height: " << truck_h << " in" << endl << "Truck Width: " << truck_w << " in" << endl << "Truck Length: " << truck_l << " in" << endl << endl;
    
    
//Calculations for max # of boxes in truck total
    maxbox_h = truck_h / box_h;
    maxbox_w = truck_w / box_w;
    maxbox_l = truck_l / box_l;
    
    totalBoxes = maxbox_h * maxbox_w * maxbox_l;
    
    
//Calculation for total volume boxes take up and what's left in truck and percentage used
    totalboxVol = totalBoxes * boxVol;
    finaltruckVol = truckVol - totalboxVol;
    percentUsed = (float(totalboxVol) / float(truckVol)) * 100; 
    
    cout <<"Total Truck interior volume: "<< truckVol << " in^2" << endl 
         << "Volume of all " << totalBoxes << " boxes: " << totalboxVol << " in^2" << endl << endl;


//Final Outputs
    cout << "Total number of boxes that can fit in truck: " << totalBoxes << endl;
    cout << "Amount of space Leftover: " << finaltruckVol << " in^2" << endl;
    cout << "Percent space used: " << percentUsed << "%" << endl;

    return 0;
}









