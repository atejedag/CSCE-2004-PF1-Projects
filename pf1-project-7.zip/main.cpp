#include "pokemon.h"
const int SIZE = 100;
int cardCount = 0; // track total number of cards stored, global variable to make it easier to add into functions

// Reads file, prompts user for file name including the file type (like .txt)
////// invalid filename terminates the program, any empty lines after the last card info causes an empty pokemon card to be created.
void arrayRead(pokemon Array[])
{
    string inputFileName;
    cout << "Type name of file you want to import into card array including the file type (ex .txt)" << endl
         << "Also make sure there are no empty lines after the last card" << endl;
    cin >> inputFileName;
    
    // usual ifstream stuff
    ifstream din;
    din.open(inputFileName);
    int i = cardCount; // choose starting point for adding new cards depending on how many cards already exist, since array starts at 0 to cardCount - 1
    while (din.eof() == false) // reads all the information on file until it reaches the end.
    {
        if (cardCount < 100) // if array is full, stop reading in cards.
        {
            Array[i].read(din);
            i = i + 1;
            cardCount = cardCount + 1; // updates card count as each new card is added
        }
        else if (cardCount > 100)
        {
            cout << "UNABLE TO ADD CARD, ARRAY FULL (MAX = 100)" << endl;
        }
    }
    din.close();
}

// Writes all pokemon in array onto .txt file
///// invalid filenames terminates the program
void arrayWrite(pokemon Array[])
{
    if (cardCount > 0)
    {
        string outputFileName;
        cout << "Type name of output file to write pokemon information on including the file type (ex .txt)" << endl;
        cin >> outputFileName;
        
        int arrayLimit = cardCount - 1;
        
        // usual ofstream stuff
        ofstream dout;
        dout.open(outputFileName);
        for (int i = 0; i <= arrayLimit; i = i + 1) // for loop to go through all cards and dout's them onto file
        {
            Array[i].write(dout);
        }
        dout.close();
    }
    else // if there are no cards in array
    {
        cout << "Pokemon card array is empty, add some cards first" << endl;
    }
}

// Prints all pokemon in array onto console
void arrayPrint(pokemon Array[])
{
    if (cardCount > 0)
    {
        int arrayLimit = cardCount - 1;
        for (int i = 0; i <= arrayLimit; i = i + 1) // for loop goes through all cards
        {
            Array[i].print();
        }
    }
    else // no cards, don't do anything
    {
        cout << "Pokemon card array is empty, add some cards first" << endl;
    }
}

// Adds card to array by promting user to type all information
///// Invalid inputs like strings cause weird "Segmentation fault (core dumped)" error
void arrayAddCard(pokemon Array[])
{
    int number;
    string name;
    int grade;
    int intEdition;
    string edition;
    float purchase;
    float sale;
    
    if (cardCount < 100)
    {
        cout << "Enter the correct information for your new card" << endl;
        
        // gather all information from input
        cout << "Pokemon number: ";
        cin >> number;
        
        cout << "Pokemon name (No spaces): ";
        cin >> name;
        
        cout << "Card grade (1-10): ";
        cin >> grade;
        
        cout << "Card edition, Choose --> [1] Unlimited, [2] Shadowless, [3] First: ";
        cin >> intEdition;
        if (int(intEdition) == false && intEdition != 0) // some worthless error checking...
        {
            cout << "Invalid input type, defaulting to Unlimited" << endl;
            edition = "Unlimited";
        }
        
        if (intEdition == 1) edition = "Unlimited";
        else if (intEdition == 2) edition = "Shadowless";
        else if (intEdition == 3) edition = "First";
        else if (intEdition > 3 || intEdition < 1) // if not in range, defaults to Unlimited
        {
            cout << "Not in range, defaulting to Unlimited" << endl;
            edition = "Unlimited";
        }
        
        
        cout << "Purchase price: ";
        cin >> purchase;
        if (float(purchase) == false && purchase != 0) // some more worthless error checking
        {
            cout << "Invalid input, defaulting to 0" << endl;
            purchase = 0;
        }
        
        cout << "Sale price (if N/A, enter 0): ";
        cin >> sale;
        if (float(sale) == false && sale != 0)
        {
            cout << "Invalid input, defaulting to 0" << endl;
            purchase = 0;
        }
        
        // assigns all the stuff
        Array[cardCount].setNumber(number);
        Array[cardCount].setName(name);
        Array[cardCount].setGrade(grade);
        Array[cardCount].setEdition(edition);
        Array[cardCount].setPurchasePrice(purchase);
        Array[cardCount].setSalePrice(sale);
        
        // updates card count
        cardCount = cardCount + 1;
    }
    else if (cardCount == 100)
    {
        cout << "CARD ARRAY FULL, UNABLE TO ADD ANY MORE CARDS" << endl;
    }
}

// Prompts user to choose one of the cards to sell and add/update sale price for the card
///// Invalid inputs, non-integers cause weird infinite loops for some reason probably because of the while loop
///// this entire thing is just huge mess trying to error check but it should work normally if no invalid data types are inputted
void arraySellCard(pokemon Array[])
{
    int cardNumber = 0;
    bool correctCard = false;
    bool incorrectInput = false;
    if (cardCount > 0)
    {
        while (correctCard == false && incorrectInput == false) // while loop to select card user wants to sell
        {
            cardNumber = 0;
            cout << "Enter array location number for card you want to sell from 1 to 100" << endl;
            cin >> cardNumber;
            
            if (int(cardNumber) == false && cardNumber != 0)
            {
                cout << "INVALID INPUT" << endl;
                incorrectInput = true;
            }
            
            if (incorrectInput == false)
            {
                if (cardNumber < cardCount && cardNumber > 0)
                {
                    int confirmCard;
                    Array[cardNumber - 1].print();
                    cout << "Is this the right card? (1 for yes, 2 for no)" << endl;
                    cin >> confirmCard;
                    
                    if (int(confirmCard) == false && cardNumber != 0)
                    {
                        cout << "INVALID INPUT" << endl;
                        incorrectInput = true;
                    }
                    
                    if (incorrectInput == false)
                    {
                        if (confirmCard == 1)
                        {
                            correctCard = true;
                            cardNumber = cardNumber - 1; // minus 1 now to use variable when calling array get method
                        }
                        else if (confirmCard == 2)
                        {
                            cout << "Try finding the right pokemon again" << endl;
                        }
                    }
                }
                else if (cardNumber > cardCount || cardNumber < 1)
                {
                    cout << "Not within range, try entering again" << endl;
                }
            }
        }
        
        
        if (incorrectInput == false) // ignore...
        {
            // checks if card isn't already sold to see if you can sell it, if not then it ends
            float salePrice;
            float salePossible = Array[cardNumber].getSalePrice();
            if (salePossible == 0)
            {
                cout << "enter sale price, enter 0 if you want to cancel" << endl;
                cin >> salePrice;
                
                if (float(salePrice == false) && salePrice != 0)
                {
                    incorrectInput = true;
                }
                
                if (incorrectInput == false)
                {
                    Array[cardNumber].setSalePrice(salePrice);
                }
                
            }
            else
            {
                cout << "Not available to sell, already sold" << endl;
            }
        }
        else if (incorrectInput == true)
        {
            cout << "Invalid input broke it, canceling..." << endl;
        }
    }
    else cout << "Pokemon card array is empty, add some cards first" << endl;
}

// Searches through array to find most valuable pokemon based on purchase price
void arrayMVC(pokemon Array[]) // MVC, Most Valuable Card
{
    int highestLocation = 0;
    float highestPrice = 0;
    for (int i = 0; i < cardCount; i = i + 1) // for loop to go through all the cards and find the most expensive purchase price
    {
        float price = Array[i].getPurchasePrice();
        if (price > highestPrice)
        {
            highestPrice = price;
        }
    }
    
    cout << "Most valuable card is worth $" << highestPrice << endl;
    if (cardCount == 0) cout << "Because there isn't any cards added yet..." << endl;
}

// Goes through collection and adds up price of all cards the user still owns and hasn't sold
void arrayWorth(pokemon Array[])
{
    float totalWorth = 0;
    for (int i = 0; i < cardCount; i = i + 1)
    {
        float isSold = Array[i].getSalePrice();
        if (isSold == 0) // check if is still owned
        {
            float cardWorth = Array[i].getPurchasePrice(); // assign's current card worth to variable and then ads it to the total worth
            totalWorth = totalWorth + cardWorth;
        }
    }
    cout << "Total collection worth is $" << totalWorth << endl;
    if (cardCount == 0) cout << "Because there isn't any cards added yet..." << endl;
}

int main()
{
    pokemon cardArray[SIZE]; // Pokemon array declaration w/const size
    bool QUIT = false;
    
    while (QUIT == false) // main while loops for input, invalid input data types makes an infinite loop
    {
        int userInput;
        cout << "Type the corresponding number to choose what to do..." << endl
             << "    Current Number of cards in collection array: " << cardCount << endl
             << "[1] To read text file to add cards to collection array" << endl
             << "[2] To write all of pokemon information onto a text file, pre-existing text will be overwritten" << endl
             << "[3] To print out all the pokemon information on screen" << endl
             << "[4] To add an individual card from input" << endl
             << "[5] To sell one of the cards and input price it was sold for" << endl
             << "[6] Find the most valuable card in collection" << endl
             << "[7] Prints on screen the total worth of all currently owned cards based on purchase price" << endl
             << "[8] QUIT" << endl;
        
        cin >> userInput;
        
        
        // if input is not an integer then quit
        // if input was 0, it would also end the program so added the != 0 as well 
        if (int(userInput) == false && userInput != 0) 
        {
            return 0;
        }
        
        if (userInput == 1) // READ
        {
            arrayRead(cardArray);
        }
        else if (userInput == 2) // WRITE
        {
            arrayWrite(cardArray);
        }
        else if (userInput == 3) // PRINT
        {
            arrayPrint(cardArray);
        }
        else if (userInput == 4) // ADD CARD
        {
            arrayAddCard(cardArray);
        }
        else if (userInput == 5) // SELL CARD
        {
            arraySellCard(cardArray);
        }
        else if (userInput == 6) // MOST VALUABLE
        {
            arrayMVC(cardArray);
        }
        else if (userInput == 7) // TOTAL WORTH
        {
            arrayWorth(cardArray);
        }
        else if (userInput == 8) // QUIT
        {
            QUIT = true;
        }
        else if (userInput > 8 || userInput < 1) // out of range integer
        {
            cout << "Input out of range, try again" << endl;
        }
    }
    
    return 0;
}