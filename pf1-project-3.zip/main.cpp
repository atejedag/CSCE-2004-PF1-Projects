#include <iostream>
#include <cstdlib>
#include <iomanip> 
using namespace std;

bool correctInput = true;
int i;
int j;
int start;
int people = 0;
float wage = 0;
int tempWeek;  //Variable for deciding hot/cool for the week
int hourWeek;  //Variable for total hours for current week
int totalhourWeek;
float weeklyWorkCost;
float weeklyProfit;
float totalProfit;
int hourlyGames;
int weeklyGames;
int totalGames;
float totalEarned;
float weeklyEarned;



int main()
{
    cout << "Welcome to the Atari game digging simulation" << endl;
    // get inputs for people hired and wage
    
    
    while (people < 1 || people > 5)
    {
        cout << "Choose amount of people you want to hire between 1 and 5" << endl;
        cin >> people;
        
        if (!(int(people)))
        {
            cout << "Not a valid input, you broke it";
            return 0;
        }
        else if (people < 1 || people > 5)
        {
            cout << "Not within range" << endl;
        }
    }
  
    
    while (wage < 9 || wage > 35)
    {
        cout << "Decide the wage for each worker between $9/hour and $35/hour" << endl;
        cin >> wage;
        
        if (!(int(wage)))
        {
            cout << "Not a valid input, you broke it";
            return 0;  
        }
        else if (wage < 9 || wage > 35)
        {
            cout << "That's not within range, try again" << endl;
        }
    }
        
    
    cout << endl << "Stats from digging for 52 weeks" << endl; 
    
    // main for loop for each week of digging
    for (i = 0; i < 52; ++i)
    {
        tempWeek = random() % 2;
        if (tempWeek == 0)
        {
            cout << "Week " << i + 1 << endl << "It's a cool week, 30 hours worked" << endl;
            totalhourWeek = 30 * people;
        }
        else if (tempWeek == 1)
        {
            cout << "Week " << i + 1 << endl << "It's a hot week, 20 hours worked" << endl;
            totalhourWeek = 20 * people;
        }
        
        
        // calculate amount of games found per hour by all workers 
        for (j = 0; j < totalhourWeek; ++j) 
        {
            hourlyGames = random() % 6 + 1;
            totalGames = totalGames + hourlyGames;
            weeklyGames = weeklyGames + hourlyGames;
        }
        
        
        // find prices for games depending on amount found that week
        if (weeklyGames > 0 && weeklyGames < 100) 
        {
            weeklyEarned = weeklyEarned + (weeklyGames * 10.0); 
        }
        else if (weeklyGames >= 100 && weeklyGames < 199) 
        {
            weeklyEarned = weeklyEarned + ((20.0 - weeklyGames/10.0) * weeklyGames);
        }
        else if (weeklyGames >= 200)
        {
            weeklyEarned = weeklyEarned + weeklyGames;
        }
        
        
        weeklyWorkCost = totalhourWeek * wage;
        weeklyProfit = weeklyEarned - weeklyWorkCost;
        
        // output weekly stats
        cout << "Games found this week: " << weeklyGames << endl;
        cout << "Price per game: $" << setprecision (2) << fixed << weeklyEarned / weeklyGames << endl;
        cout << "Money made this week: $" << weeklyEarned << endl;
        cout << "Worker's pay for this week: $" << weeklyWorkCost << endl;
        cout << "Profit: $" << setprecision (2) << fixed << weeklyProfit << endl;
        totalProfit = totalProfit + weeklyProfit;
        
        cout << "Total games found so far: " << totalGames << endl << endl;
        
        // reset weekly counters
        weeklyGames = 0; 
        weeklyEarned = 0; 
    }
    
    // final outputs after 52 weeks
    
    if (totalProfit > 0)
    {
        cout << "In the end you made a profit of $" << setprecision (2) << fixed << totalProfit << endl;
    }
    else if (totalProfit < 0)
    {
        cout << "In the end you had a loss of $" << setprecision (2) << fixed << totalProfit << endl;
    }

    return 0;
}









